coreBOS
=======

**core Business Operating System**

Come on over to [our website](http://corebos.org/) for full details of the project and follow us on [Google+](https://plus.google.com/communities/109845486286232591652) and [LinkedIn](http://www.linkedin.com/groups/coreBOS-7479130?trk=my_groups-b-grp-v) for regular updates.


**Thank you** very much for your help and contribution.

*coreBOS Team*
