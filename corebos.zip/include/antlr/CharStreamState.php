<?php
	class CharStreamState {
	}
?>