<?php
header("Location: modules/Mobile");
?>