<?php
$custom_strings = array(
	'CustomScriptLabel' => 'Translation From Custom Strings for Unit Testing',
);