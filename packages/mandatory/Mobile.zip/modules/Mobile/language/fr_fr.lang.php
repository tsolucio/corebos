<?php
/***********************************************************************************
*  Module        : Mobile
*  Language     : French
*  Version      : 5.3.0 
*  License      : GPL
*  Author       : ABOnline solutions http://www.vtiger-crm.fr

***********************************************************/
$mod_strings = Array (
	'Mobile' => 'Mobile',
);

?>