<?php
/**
  JPL TSolucio, S.L. 2009 MPL
  Joe Bordes
  *  Author       : Francisco Hernandez Odin Consultores www.odin.mx

 **/
$mod_strings = Array (
'FieldFormulas' => 'Campos calculados',
'LBL_FIELDFORMULAS'=>'Campos calculados',
'LBL_FIELDFORMULAS_DESCRIPTION'=>'Agregar ecuaciones a campos personalizados', 
'LBL_FIELDS' => 'Campos',
'LBL_FUNCTIONS'=>'Funciones',
'LBL_FIELD' => 'Campo',
'LBL_EXPRESSION'=>'Expresión',
'LBL_SETTINGS' => 'Configuración',
'LBL_NEW_FIELD_EXPRESSION_BUTTON' => 'Nueva Expresión de Campo',
'LBL_EDIT_EXPRESSION' => 'Editar Expresión',
'LBL_MODULE_INFO' => 'Fórmulas definidas para',
'NEED_TO_ADD_A' =>'Tienes que agregar un tipo cadena o entero ',
'LBL_CUSTOM_FIELD' =>'Campo personalizado',
'LBL_CHECKING'=>'Comprobando...',
'LBL_SELECT_ONE_DOTDOTDOT'=>'Selecciona Uno...',
'LBL_TARGET_FIELD'=>'Campo objetivo',
'LBL_DELETE_EXPRESSION_CONFIRM'=>'¿Seguro que quieres eliminar esta expresión?',
'LBL_EXAMPLES'=>'Ejemplos',
'LBL_USE_FIELD_VALUE_DASHDASH'=>'-- Utilizar Valor de Campo --',
'LBL_USE_FUNCTION_DASHDASH'=>'-- Utilizar Función --',

);

?>
