<?php
/***********************************************************
*  Module       : Asterisk
*  Language     : ES Spanish
*  Version      : vt5.4.0
*  Created Date : 2012-02-27
*  Author       : Odin Consultores S de RL de CV
*  License      : MPL 1.1
***********************************************************/
$mod_strings = Array(
	'Asterisk' => 'Asterisk',
	'LBL_ASTERISK_INFORMATION' => 'Información ASTERISK',
	'Call From'=>'Llamada de',
	'Call To'=>'Llamar a',
	'Time Of Call'=>'Tiempo de Llamada',
	'PBXManager ID'=>'Id PBX Manager',
);

?>
